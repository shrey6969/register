import { useState } from "react";
import './App.css';
export default function App(){
  const [name,setname]=useState('');
  const [email,setemail]=useState('');
  const [password,setpassword]=useState('');
  const [submit,setsubmit]=useState(false);

  const username=(e)=>{
    setname(e.target.value);
  };

  const useremail=(e)=>{
    setemail(e.target.value);
  };

  const userpassword=(e)=>{
    setpassword(e.target.value);
  };

  const usersubmit=(e)=>{
    e.preventDefault();
    if(name==='' || email ==='' || password ===''){
      alert("enter all the fields");
    }
    else{
      setsubmit(true);
    }
  };
  const successmsg=()=>{
    if(submit)
    return(
     <div className="mdg">
      <h1>user {name} registered succesfully</h1>
     </div>
  );
  };
  return(
    <div className="form">
      <div>
        user registration
      </div>
      <div>
        {successmsg()}
      </div>
      <form >
        <fieldset>
          <label >Name</label>
          <input type="text" value={name} onChange={username} /><br />
          <label >Email</label>
          <input type="email" value={email} onChange={useremail}/><br />
          <label >Password</label>
          <input type="password" value={password} onChange={userpassword} /><br />
          <button onClick={usersubmit} type="submit">submit</button>

        </fieldset>
      </form>
    </div>
  );

}